
package testadigrafo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author joao.lucasdosSantosLima && Julia Martins
 Cliente do TAD - digraph
 */
public class TestaDigrafo {
    public static void main(String[] args) throws FileNotFoundException, IOException{
        digraph G;
        int fogo;
        // instancia um objeto da classe digraph
        G = new digraph(20);
        //Config inimigos
        FileReader arquivo = new FileReader("src\\testadigrafo\\caminho.txt");
        BufferedReader bufferArquivo = new BufferedReader(arquivo);
        
        System.out.println("arquivo aberto corretamente");
        
        String linha = bufferArquivo.readLine(); // lê a primeira linha
        String linhaUm[] = linha.split(" ");
        fogo = Integer.parseInt(linhaUm[0]);
        
        int indiceLinha = 0;
        boolean linhafinal = false;
        //percorre enquanto a linha não estiver nula
        while (linha != null) {
            //divide a linha atual em um array utilizando " " como separador
            String linhas[] = linha.split(" ");
            //pecas[indiceLinha] = new Inimigos(this,Integer.parseInt(linhas[0]));
            if (linhas.length == 1){
                indiceLinha++;
                linha = bufferArquivo.readLine(); // lê proxima linha
                continue;
            }
            if(Integer.parseInt(linhas[0])== 0 && Integer.parseInt(linhas[1])== 0){                
                linha = null;
            }else{
                G.insereA(Integer.parseInt(linhas[0]),Integer.parseInt(linhas[1]));                
            }   
            indiceLinha++;
            linha = bufferArquivo.readLine(); // lê proxima linha
        }   
        
        /*
        // insere uma aresta
        G.insereA(1, 2);
        G.insereA(1, 3);
        G.insereA(2, 2);
        G.insereA(3, 4);
        G.insereA(3, 5);
        G.insereA(4, 6);
        G.insereA(5, 6);
        G.insereA(5, 1);
        G.insereA(2, 3);
        G.insereA(2, 4);
        G.insereA(1, 3);
       // G.insereA(0, 0); //final
        */
        
        /*
        System.out.println("Removendo vertices");
        G.removeA(0, 3);
        
        System.out.println("");
        System.out.println("Quantidades de saidas do 0");
        System.out.println(G.outdeg(0));
        
        System.out.println("");
        System.out.println("Quantidades de entradas do 5");
        System.out.println(G.indeg(5));
        
        System.out.println("");
        System.out.println("Digrafo atual");
        G.mostra();
        
        System.out.println("");
        System.out.println("teste de busca");
        G.busca(G);
        */
        G.buscaCaminho(G,1,fogo,"");
    }
    
}
